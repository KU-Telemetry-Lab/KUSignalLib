def addTwoNums(a, b):
    return a + b