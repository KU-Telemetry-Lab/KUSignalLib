import scipy
import mat73

def loadMatLabFile(file_path):
    """Load a .mat file and return the data as a dictionary using scipy.io.loadmat"""
    mat = scipy.io.loadmat(file_path)
    return mat